drop table nation;

drop table region;

drop table part;

drop table supplier;

drop table partsupp;

drop table customer;

drop table orders;

drop table lineitem;

CREATE TABLE nation
(
    N_NATIONKEY NUMBER   NOT NULL,
    N_NAME      CHAR(25) NOT NULL,
    N_REGIONKEY NUMBER   NOT NULL,
    N_COMMENT   VARCHAR(152)
);

CREATE TABLE region
(
    R_REGIONKEY NUMBER   NOT NULL,
    R_NAME      CHAR(25) NOT NULL,
    R_COMMENT   VARCHAR(152)
);

CREATE TABLE part
(
    P_PARTKEY     NUMBER        NOT NULL,
    P_NAME        VARCHAR(200)  NOT NULL,
    P_MFGR        CHAR(25)      NOT NULL,
    P_BRAND       CHAR(10)      NOT NULL,
    P_TYPE        VARCHAR(25)   NOT NULL,
    P_SIZE        NUMBER        NOT NULL,
    P_CONTAINER   CHAR(10)      NOT NULL,
    P_RETAILPRICE NUMBER(15, 2) NOT NULL,
    P_COMMENT     VARCHAR(23)   NOT NULL
);

CREATE TABLE supplier
(
    S_SUPPKEY   NUMBER         NOT NULL,
    S_NAME      CHAR(30)       NOT NULL,
    S_ADDRESS   VARCHAR(40)    NOT NULL,
    S_NATIONKEY NUMBER         NOT NULL,
    S_PHONE     CHAR(15)       NOT NULL,
    S_ACCTBAL   DECIMAL(15, 2) NOT NULL,
    S_COMMENT   VARCHAR(101)   NOT NULL
);

CREATE TABLE partsupp
(
    PS_PARTKEY    NUMBER         NOT NULL,
    PS_SUPPKEY    NUMBER         NOT NULL,
    PS_AVAILQTY   NUMBER         NOT NULL,
    PS_SUPPLYCOST DECIMAL(15, 2) NOT NULL,
    PS_COMMENT    VARCHAR(199)   NOT NULL
);

CREATE TABLE customer
(
    C_CUSTKEY    NUMBER         NOT NULL,
    C_NAME       VARCHAR(25)    NOT NULL,
    C_ADDRESS    VARCHAR(40)    NOT NULL,
    C_NATIONKEY  NUMBER         NOT NULL,
    C_PHONE      CHAR(15)       NOT NULL,
    C_ACCTBAL    DECIMAL(15, 2) NOT NULL,
    C_MKTSEGMENT CHAR(10)       NOT NULL,
    C_COMMENT    VARCHAR(117)   NOT NULL
);

CREATE TABLE orders
(
    O_ORDERKEY      NUMBER         NOT NULL,
    O_CUSTKEY       NUMBER         NOT NULL,
    O_ORDERSTATUS   CHAR(1)        NOT NULL,
    O_TOTALPRICE    DECIMAL(15, 2) NOT NULL,
    O_ORDERDATE     DATE           NOT NULL,
    O_ORDERPRIORITY CHAR(15)       NOT NULL,
    O_CLERK         CHAR(15)       NOT NULL,
    O_SHIPPRIORITY  NUMBER         NOT NULL,
    O_COMMENT       VARCHAR(79)    NOT NULL
);

CREATE TABLE lineitem
(
    L_ORDERKEY      NUMBER         NOT NULL,
    L_PARTKEY       NUMBER         NOT NULL,
    L_SUPPKEY       NUMBER         NOT NULL,
    L_LINENUMBER    NUMBER         NOT NULL,
    L_QUANTITY      DECIMAL(15, 2) NOT NULL,
    L_EXTENDEDPRICE DECIMAL(15, 2) NOT NULL,
    L_DISCOUNT      DECIMAL(15, 2) NOT NULL,
    L_TAX           DECIMAL(15, 2) NOT NULL,
    L_RETURNFLAG    CHAR(1)        NOT NULL,
    L_LINESTATUS    CHAR(1)        NOT NULL,
    L_SHIPDATE      DATE           NOT NULL,
    L_COMMITDATE    DATE           NOT NULL,
    L_RECEIPTDATE   DATE           NOT NULL,
    L_SHIPINSTRUCT  CHAR(25)       NOT NULL,
    L_SHIPMODE      CHAR(10)       NOT NULL,
    L_COMMENT       VARCHAR(44)    NOT NULL
);

-- End