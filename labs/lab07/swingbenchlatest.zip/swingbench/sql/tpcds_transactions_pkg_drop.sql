drop TYPE integer_return_array;

drop PACKAGE BODY pkg_tpcds_transactions;

drop PACKAGE pkg_tpcds_transactions;

-- End;