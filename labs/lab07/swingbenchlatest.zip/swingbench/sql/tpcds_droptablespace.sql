drop tablespace &tablespace including contents and datafiles;

drop tablespace &indextablespace including contents and datafiles;


-- Exit